<?php

namespace App\Http\Controllers\Comercio\Facturacion\compAntigua;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Artisaninweb\SoapWrapper\SoapWrapper;
use Spatie\ArrayToXml\ArrayToXml;
use Carbon\Carbon;
use ControlCode;
use DOMDocument;
use SimpleXMLElement;
use PharData;
use Phar;
use DirectoryIterator;
use Exception;
use Iterator;
use stdClass;
include 'ControlCode.php';


class PrincipalController extends Controller
{
    protected $controlCode;
    public function __construct()
    {
        $this->controlCode = new ControlCode();
    }
    public function index2(){

        $Re ='$f';
     
        $res=$this->controlCode->generate("7904006306693","876814","1665979","20080519","35958,60",
        'zZ7Z]xssKqkEf_6K9uH(EcV+%x+u[Cca9T%+_$kiLjT8(zr3T9b5Fx2xG-D+_EBS');
    dd($res);
    }
    public function index()
    {

        try {
            $filename = "5000casos.txt";
            $handle = fopen($filename, "r");
            if ($handle) {
                $controlCode = new ControlCode();
                $count = 0;
                while (($line = fgets($handle)) !== false) {
                    $reg = explode("|", $line);               
                    $code = $controlCode->generate(
                        $reg[0], 
                        $reg[1], 
                        $reg[2], 
                        str_replace('/', '', $reg[3]),
                        $reg[4], 
                        $reg[5] 
                    );
                    if ($code === $reg[10]) {
                        $count += 1;
                        //echo json_encode($reg);
                    }
                }
                dd($count);
                fclose($handle);
            } else {
                throw new Exception("<b>Could not open the file!</b>");
            }
        } catch (Exception $e) {
            echo "Error (File: " . $e->getFile() . ", line " .
                $e->getLine() . "): " . $e->getMessage();
        }
    }
}
